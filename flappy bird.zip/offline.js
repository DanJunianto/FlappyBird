﻿{
	"version": 1709166828,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/171406one_punch_man_dpsaitamaone_punch_mananimesleeve550x-sheet0.png",
		"images/istockphoto1253231143170667a-sheet0.png",
		"images/player-sheet0.png",
		"images/player-sheet1.png",
		"images/bawah-sheet0.png",
		"images/atas-sheet0.png",
		"images/freehdconvertcomistockphoto1253231143170667a-sheet0.png",
		"images/freehdconvertcomistockphoto1253231143170667a2-sheet0.png",
		"images/whatsappimage20240215at-sheet0.png",
		"images/whatsappimage20240215at-sheet1.png",
		"images/whatsappimage20240215at-sheet2.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}